package com.sena.servicesecurity.DTO;

public interface IDepartmentDto extends IGenericDto {
	String getName_department();

	String getCode_department();

	String getCountry();
}

package com.sena.servicesecurity.DTO;

public interface IRoleDto extends IGenericDto {

	String getRole();

	String getDescription();
}

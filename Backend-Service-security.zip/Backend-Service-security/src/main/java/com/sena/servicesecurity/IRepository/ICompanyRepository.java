package com.sena.servicesecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sena.servicesecurity.DTO.ICompanyDto;
import com.sena.servicesecurity.Entity.Company;

public interface ICompanyRepository extends IBaseRepository<Company, Long> {


}

package com.sena.servicesecurity.DTO;

public interface IContractDto extends IGenericDto {

	String getCode();

	String getStart_Date();

	String getEnd_Date();

	String getSalary();

	String getObject();

}

package com.sena.servicesecurity.DTO;

import java.util.List;

public interface IEmployedDto extends IGenericDto {
	String getSalary();

}

package com.sena.servicesecurity.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sena.servicesecurity.DTO.IPositionDto;
import com.sena.servicesecurity.Entity.Position;
import com.sena.servicesecurity.IRepository.IBaseRepository;
import com.sena.servicesecurity.IRepository.IPositionRepository;

import com.sena.servicesecurity.IService.IPositionService;
@Service
public class PositionService extends ABaseService<Position> implements IPositionService {


	@Autowired
	private IPositionRepository repository;
	
	
    @Override
	protected IBaseRepository<Position, Long> getRepository() {
		// TODO Auto-generated method stub
		return null;
	}



}

package com.sena.servicesecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sena.servicesecurity.DTO.IPositionDto;
import com.sena.servicesecurity.Entity.Position;

public interface IPositionRepository extends IBaseRepository<Position, Long> {

}

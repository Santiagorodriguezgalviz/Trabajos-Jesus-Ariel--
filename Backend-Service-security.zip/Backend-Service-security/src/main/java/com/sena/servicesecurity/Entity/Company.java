package com.sena.servicesecurity.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "campany")
public class Company extends ABaseEntity {
	@Column(name = "nit", length = 50, nullable = false)
	private String Nit;
	@Column(name = "direccion", length = 50, nullable = false)
	private String Direccion;

	@Column(name = "telefono", length = 50, nullable = false)
	private String Telefono;
	@Column(name = "correo", length = 50, nullable = false)
	private String Correo;
	@Column(name = "wed", length = 50, nullable = false)
	private String Wed;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "city_id", nullable = false)
	private City city;

	public String getNit() {
		return Nit;
	}

	public void setNit(String nit) {
		Nit = nit;
	}

	public String getDireccion() {
		return Direccion;
	}

	public void setDireccion(String direccion) {
		Direccion = direccion;
	}

	public String getTelefono() {
		return Telefono;
	}

	public void setTelefono(String telefono) {
		Telefono = telefono;
	}

	public String getCorreo() {
		return Correo;
	}

	public void setCorreo(String correo) {
		Correo = correo;
	}

	public String getWed() {
		return Wed;
	}

	public void setWed(String wed) {
		Wed = wed;
	}

}

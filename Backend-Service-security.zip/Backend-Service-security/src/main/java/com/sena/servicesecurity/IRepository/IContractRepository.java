package com.sena.servicesecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sena.servicesecurity.DTO.IContractDto;
import com.sena.servicesecurity.Entity.Contract;

public interface IContractRepository extends IBaseRepository<Contract, Long> {


}

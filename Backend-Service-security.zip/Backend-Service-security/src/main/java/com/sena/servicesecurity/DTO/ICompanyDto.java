package com.sena.servicesecurity.DTO;

public interface ICompanyDto extends IGenericDto {

	String getNit();

	String getDireccion();

	String getTelefono();

	String getCorreo();

	String getWed();
}

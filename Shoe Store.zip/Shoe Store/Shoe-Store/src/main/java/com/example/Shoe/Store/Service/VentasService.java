package com.example.Shoe.Store.Service;

import java.util.List;

import com.example.Shoe.Store.Dto.IVentasDto;

import com.example.Shoe.Store.Entity.Ventas;
import com.example.Shoe.Store.IRepository.IBaseRepository;

import com.example.Shoe.Store.IService.IVentasService;

public class VentasService extends ABaseService<Ventas> implements IVentasService {

    @Override
    public List<IVentasDto> getListIVentasDtos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getListIVentasDtos'");
    }

    @Override
    protected IBaseRepository<Ventas, Long> getRepository() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getRepository'");
    }

}
    


package com.example.Shoe.Store.IService;

import java.util.List;

import com.example.Shoe.Store.Dto.IVentasDto;
import com.example.Shoe.Store.Entity.Ventas;

public interface IVentasService extends IBaseService<Ventas> {

	List<IVentasDto> getListIVentasDtos();

}

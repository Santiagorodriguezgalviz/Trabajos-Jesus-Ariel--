package com.example.Shoe.Store.Service;

import org.springframework.stereotype.Service;

import com.example.Shoe.Store.IService.IEnumService;
import com.example.Shoe.Store.Utils.tipo_identificacion;
import com.example.Shoe.Store.Utils.direccion;

@Service
public class EnumService implements IEnumService{
	
	@Override
    public tipo_identificacion[] getTypoIdentificacion() {
        return tipo_identificacion.values();
    }
	
	@Override
	public direccion[] getDireccion() {
		// TODO Auto-generated method stub
		return direccion.values();
	}
}
package com.example.Shoe.Store.IService;

import java.util.List;

import com.example.Shoe.Store.Dto.IClientesDto;
import com.example.Shoe.Store.Entity.Clientes;

public interface IClientesService extends IBaseService<Clientes> {

	List<IClientesDto> getList();

	List<IClientesDto> getTipo_identificacion(String type);


}

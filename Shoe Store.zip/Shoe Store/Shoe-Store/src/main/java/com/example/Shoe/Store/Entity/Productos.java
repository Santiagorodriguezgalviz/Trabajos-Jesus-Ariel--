package com.example.Shoe.Store.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "productos")
public class Productos extends ABaseEntity {
	
	@Column(name = "Nombre", nullable = false, unique = false)
	private String Nombre;

	@Column(name = "Descripcion", nullable = false, unique = false)
	private String Descripcion;

	@Column(name = "Cantidad", nullable = false, unique = false)
	private String Cantidad;

	@Column(name = "Precio", nullable = false, unique = false)
	private String Precio;

	@Column(name = "Porcentaje_iva", nullable = false, unique = false)
	private String Porcentaje_iva;

	@Column(name = "Porcentaje_descuento", nullable = false, unique = false)
	private String Porcentaje_descuento;

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getDescripcion() {
		return Descripcion;
	}

	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

	public String getCantidad() {
		return Cantidad;
	}

	public void setCantidad(String cantidad) {
		Cantidad = cantidad;
	}

	public String getPrecio() {
		return Precio;
	}

	public void setPrecio(String precio) {
		Precio = precio;
	}

	public String getPorcentaje_iva() {
		return Porcentaje_iva;
	}

	public void setPorcentaje_iva(String porcentaje_iva) {
		Porcentaje_iva = porcentaje_iva;
	}

	public String getPorcentaje_descuento() {
		return Porcentaje_descuento;
	}

	public void setPorcentaje_descuento(String porcentaje_descuento) {
		Porcentaje_descuento = porcentaje_descuento;
	}
	
}
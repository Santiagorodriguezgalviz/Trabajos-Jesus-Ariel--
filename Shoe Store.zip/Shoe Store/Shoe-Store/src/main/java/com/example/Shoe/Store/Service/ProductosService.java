package com.example.Shoe.Store.Service;

import java.util.List;

import com.example.Shoe.Store.Dto.IProductosDto;

import com.example.Shoe.Store.Entity.Productos;
import com.example.Shoe.Store.IRepository.IBaseRepository;

import com.example.Shoe.Store.IService.IProductosService;

public class ProductosService extends ABaseService<Productos> implements IProductosService {

    @Override
    public List<IProductosDto> getListProductosDtos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getListProductosDtos'");
    }

    @Override
    protected IBaseRepository<Productos, Long> getRepository() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getRepository'");
    }
}
    


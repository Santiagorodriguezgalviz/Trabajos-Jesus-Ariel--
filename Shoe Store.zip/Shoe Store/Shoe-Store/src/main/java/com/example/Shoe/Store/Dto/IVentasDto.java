package com.example.Shoe.Store.Dto;

public interface IVentasDto extends IGenericDto {
	
    String getTotal();

	String getFecha_venta();

}

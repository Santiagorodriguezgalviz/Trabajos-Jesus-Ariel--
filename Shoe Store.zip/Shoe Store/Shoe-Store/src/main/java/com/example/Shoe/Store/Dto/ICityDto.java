package com.example.Shoe.Store.Dto;

public interface ICityDto extends IGenericDto {
	
	String getName();

	String getCode();	

}

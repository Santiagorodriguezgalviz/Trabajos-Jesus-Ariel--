package com.example.Shoe.Store.Service;

import java.util.List;

import com.example.Shoe.Store.Dto.IDescripcion_ventasDto;

import com.example.Shoe.Store.Entity.Descripcion_ventas;
import com.example.Shoe.Store.IRepository.IBaseRepository;

import com.example.Shoe.Store.IService.IDescripcion_ventasService;

public class Descripcion_ventasService extends ABaseService<Descripcion_ventas> implements IDescripcion_ventasService {

    @Override
    public List<IDescripcion_ventasDto> getListDescripcion_ventasDtos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getListDescripcion_ventasDtos'");
    }

    @Override
    protected IBaseRepository<Descripcion_ventas, Long> getRepository() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getRepository'");
    }
}

package com.example.Shoe.Store.IService;

import java.util.List;

import com.example.Shoe.Store.Dto.IDescripcion_ventasDto;
import com.example.Shoe.Store.Entity.Descripcion_ventas;


public interface IDescripcion_ventasService extends IBaseService<Descripcion_ventas> {

	List<IDescripcion_ventasDto> getListDescripcion_ventasDtos();

}

package com.example.Shoe.Store.Dto;

public interface IProductosDto extends IGenericDto {
	
	String getNombre();

	String getDescripcion();

	String getCantidad();

	String getPrecio();

	String getPorcentaje_iva();

	String getPorcentaje_descuento();
	

}

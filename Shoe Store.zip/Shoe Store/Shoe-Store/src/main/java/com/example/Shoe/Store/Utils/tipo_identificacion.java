package com.example.Shoe.Store.Utils;

public enum tipo_identificacion {

	ti,
	cc,
	rc,
	ps,
	cex

}

package com.example.Shoe.Store.Dto;

public interface IDescripcion_ventasDto extends IGenericDto {
	
	String getCantidad();

	String getPrecio();

	String getDescuento();

	String getSub_total();

	String getVentas();

	String getProductos();
	

}

package com.example.Shoe.Store.IService;

import java.util.List;


import com.example.Shoe.Store.Dto.IProductosDto;
import com.example.Shoe.Store.Entity.Productos;

public interface IProductosService extends IBaseService<Productos> {

	List<IProductosDto> getListProductosDtos();

}
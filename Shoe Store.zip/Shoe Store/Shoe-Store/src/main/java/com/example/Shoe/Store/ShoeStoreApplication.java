package com.example.Shoe.Store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoeStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoeStoreApplication.class, args);
	}

}

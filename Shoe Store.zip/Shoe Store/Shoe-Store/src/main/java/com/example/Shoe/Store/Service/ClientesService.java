package com.example.Shoe.Store.Service;


import java.util.List;



import org.springframework.stereotype.Service;


import com.example.Shoe.Store.Dto.IClientesDto;
import com.example.Shoe.Store.Entity.Clientes;
import com.example.Shoe.Store.IRepository.IBaseRepository;
import com.example.Shoe.Store.IService.IClientesService;

@Service
public class ClientesService extends ABaseService<Clientes> implements IClientesService {

    @Override
    public List<IClientesDto> getList() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getList'");
    }

    @Override
    public List<IClientesDto> getTipo_identificacion(String type) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getTipo_identificacion'");
    }

    @Override
    protected IBaseRepository<Clientes, Long> getRepository() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getRepository'");
    }

  

	
	}

	
    
    

    

package com.example.Shoe.Store.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "descripcion_ventas")
public class Descripcion_ventas extends ABaseEntity {

	
	@Column(name = "Cantidad", nullable = false, unique = false)
	private String Cantidad;

	@Column(name = "Precio", nullable = false, unique = false)
	private String Precio;

	@Column(name = "Descuento", nullable = false, unique = false)
	private String Descuento;

	@Column(name = "sub_total", nullable = false, unique = false)
	private String sub_total;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "ventas_id", nullable = false)
	private Ventas ventas;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "productos_id", nullable = false)
	private Productos productos;

	public String getCantidad() {
		return Cantidad;
	}

	public void setCantidad(String cantidad) {
		Cantidad = cantidad;
	}

	public String getPrecio() {
		return Precio;
	}

	public void setPrecio(String precio) {
		Precio = precio;
	}

	public String getDescuento() {
		return Descuento;
	}

	public void setDescuento(String descuento) {
		Descuento = descuento;
	}

	public String getSub_total() {
		return sub_total;
	}

	public void setSub_total(String sub_total) {
		this.sub_total = sub_total;
	}

	public Ventas getVentas() {
		return ventas;
	}

	public void setVentas(Ventas ventas) {
		this.ventas = ventas;
	}

	public Productos getProductos() {
		return productos;
	}

	public void setProductos(Productos productos) {
		this.productos = productos;
	}


}

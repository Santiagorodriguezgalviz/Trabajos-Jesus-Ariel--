package com.example.Shoe.Store.IRepository;

public class IVentasRepository {
    
}

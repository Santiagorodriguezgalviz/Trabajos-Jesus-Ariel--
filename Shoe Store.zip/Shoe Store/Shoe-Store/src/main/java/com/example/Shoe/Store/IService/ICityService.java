package com.example.Shoe.Store.IService;

import java.util.List;

import com.example.Shoe.Store.Dto.ICityDto;
import com.example.Shoe.Store.Entity.City;

public interface ICityService extends IBaseService<City> {

	List<ICityDto> geListCityDtos();

}

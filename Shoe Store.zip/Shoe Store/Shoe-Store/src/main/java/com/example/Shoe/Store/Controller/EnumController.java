package com.example.Shoe.Store.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.Shoe.Store.IService.IEnumService;
import com.example.Shoe.Store.Utils.tipo_identificacion;
import com.example.Shoe.Store.Utils.direccion;

public class EnumController {
	
	@Autowired
	private IEnumService service;
	
	@GetMapping("/tipoidentificacion")
	public tipo_identificacion[] identificacion() {
		return service.getTypoIdentificacion();
	}
	
	@GetMapping("/direccion")
	public direccion[] direccion() {
	    return service.getDireccion();
	    
	}

}

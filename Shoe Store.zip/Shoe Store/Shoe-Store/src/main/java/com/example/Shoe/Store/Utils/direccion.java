package com.example.Shoe.Store.Utils;

public enum direccion {
	calle,
	carerra,
	bis,
	transversal
}

package com.example.Shoe.Store.IRepository;

public class IDescripcion_ventas {
    
}

package com.example.Shoe.Store.Dto;

import java.time.LocalDate;

public interface IClientesDto extends IGenericDto {
	String getNombre_cliente();

	String getApellido_cliente();

	String getTipo_identificacion();

	String getIdentificacion();

	String getTelefono();

	String getDireccion();
	
	LocalDate getCiudad();

}

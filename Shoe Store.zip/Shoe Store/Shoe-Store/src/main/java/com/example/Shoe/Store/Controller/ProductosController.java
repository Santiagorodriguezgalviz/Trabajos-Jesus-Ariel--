package com.example.Shoe.Store.Controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Shoe.Store.Entity.Productos;
import com.example.Shoe.Store.IService.IProductosService;


@RestController
@RequestMapping("v1/api/productos")
public class ProductosController extends ABaseController<Productos, IProductosService>{

	protected ProductosController(IProductosService service) {
		super(service, "Productos");
		// TODO Auto-generated constructor stub
	}

}

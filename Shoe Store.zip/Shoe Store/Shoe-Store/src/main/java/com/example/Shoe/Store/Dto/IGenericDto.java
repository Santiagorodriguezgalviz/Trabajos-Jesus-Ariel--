package com.example.Shoe.Store.Dto;

public interface IGenericDto {
	Long getId();

	Boolean getState();
}

package com.example.Shoe.Store.IService;

import com.example.Shoe.Store.Utils.tipo_identificacion;
import com.example.Shoe.Store.Utils.direccion;

public interface IEnumService {
	
	tipo_identificacion[] getTypoIdentificacion();
	
	direccion[] getDireccion();

}

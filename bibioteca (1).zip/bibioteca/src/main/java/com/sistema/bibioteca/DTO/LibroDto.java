package com.sistema.bibioteca.DTO;

public interface LibroDto {
	
	Long getId();
    String getTitulo(); // Ejemplo de atributo
    String getAutor(); // Ejemplo de atributo
    // Otros métodos para los atributos que deseas exponer en el DTO

}

package com.sistema.bibioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibiotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibiotecaApplication.class, args);
	}

}

package com.sistema.bibioteca.DTO;

public interface ReservaDto {
	
	Long getId();
    Long getIdUsuario(); // Ejemplo de atributo
    Long getIdLibro(); // Ejemplo de atributo
    // Otros métodos para los atributos que deseas exponer en el DTO
}

package com.sistema.bibioteca.DTO;

public interface IGenericDto {

	Long getId();

	Boolean getState();
}


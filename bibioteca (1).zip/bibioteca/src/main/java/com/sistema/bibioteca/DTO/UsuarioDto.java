package com.sistema.bibioteca.DTO;

public interface UsuarioDto {
	
	Long getId();
    String getNombre(); // Ejemplo de atributo
    String getEmail(); // Ejemplo de atributo
    String getTelefono(); // Ejemplo de atributo
    // Otros métodos para los atributos que deseas exponer en el DTO

}

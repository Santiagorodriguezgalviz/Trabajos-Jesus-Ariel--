package com.sistema.bibioteca.DTO;

public interface EjemplarDto {
	
	Long getId();
    Long getIdLibro(); // Ejemplo de atributo
    String getUbicacion(); // Ejemplo de atributo
    // Otros métodos para los atributos que deseas exponer en el DTO
}

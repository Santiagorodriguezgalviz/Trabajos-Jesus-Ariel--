package com.example.service.security.Utils;

public enum Type_Document {

	TI,
	CC,
	RC,
	PS,
	CEX

}

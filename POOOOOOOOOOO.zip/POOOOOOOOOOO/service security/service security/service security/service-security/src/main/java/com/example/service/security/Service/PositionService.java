package com.example.service.security.Service;

import com.example.service.security.Dto.ICountryDto;
import com.example.service.security.Dto.IPositionDto;
import com.example.service.security.Entity.Position;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.IPositionRepository;
import com.example.service.security.IService.IPositionService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PositionService extends ABaseService<Position> implements IPositionService{

	@Override
	public IBaseRepositoy<Position, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}
	
	@Override
    public void delete(Long id) {
        repository.deleteById(id);
    }
	
	@Autowired
	public IPositionRepository repository;

	@Override
	public List<IPositionDto> getListPositions() {
		// TODO Auto-generated method stub
		return repository.getListPositions();
	}

	

}

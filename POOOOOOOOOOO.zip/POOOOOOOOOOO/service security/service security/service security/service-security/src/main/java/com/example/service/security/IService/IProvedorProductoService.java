package com.example.service.security.IService;

import com.example.service.security.Entity.ProvedorProducto;

import java.util.List;

import com.example.service.security.Dto.ProvedorProductoDto;

public interface IProvedorProductoService extends IBaseService<ProvedorProducto> {

	List<ProvedorProductoDto> getListProvedorProducto();

}

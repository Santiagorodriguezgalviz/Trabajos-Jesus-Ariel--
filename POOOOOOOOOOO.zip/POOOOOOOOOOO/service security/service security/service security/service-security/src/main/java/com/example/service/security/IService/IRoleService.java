package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.IRoleDto;
import com.example.service.security.Entity.Role;

public interface IRoleService extends IBaseService<Role> {

	List<IRoleDto> getList();

}

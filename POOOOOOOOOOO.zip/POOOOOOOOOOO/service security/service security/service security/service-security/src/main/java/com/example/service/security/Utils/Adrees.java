package com.example.service.security.Utils;

public enum Adrees {
	calle,
	carerra,
	bis,
	transversal
}

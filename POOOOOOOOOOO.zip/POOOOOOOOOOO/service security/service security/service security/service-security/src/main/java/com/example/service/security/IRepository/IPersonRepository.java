package com.example.service.security.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.IPersonDto;
import com.example.service.security.Entity.Person;

@Repository
public interface IPersonRepository extends IBaseRepositoy<Person, Long> {
	@Query(value = " SELECT  " + " id, " + " concat(first_name,'  ',last_name) as person " + "	FROM  " + "	person "
			+ "	WHERE  " + " deleted_at IS NULL", nativeQuery = true)
	List<IPersonDto> getList();

	@Query(value = " SELECT  " + " id, " + " concat(first_name,'  ',last_name) as person " + "	FROM  " + "	person "
			+ "	WHERE  " + " deleted_at IS NULL", nativeQuery = true)
	List<Object[]> getDList();

	@Query(value = "SELECT " + "p.id, " + "CONCAT(p.first_name, ' ', p.last_name) AS person, " + "p.document " + "FROM "
			+ "person p " + "LEFT JOIN customer c ON p.id = c.person_id " + "WHERE " + "p.Document_Type = :type AND "
			+ "c.person_id IS NULL AND " + "p.deleted_at IS NULL", nativeQuery = true)
	List<IPersonDto> getTypeDocument(@Param("type") String type);

	@Query(value = "SELECT\r\n" + "\r\n" + "    \r\n" + "    person.document,\r\n" + "   \r\n"
			+ "    person.type_document\r\n" + "   \r\n" + "FROM service_security.person\r\n"
			+ "where id = :id", nativeQuery = true)
	IPersonDto getDocument(@Param("id") Long id);

}

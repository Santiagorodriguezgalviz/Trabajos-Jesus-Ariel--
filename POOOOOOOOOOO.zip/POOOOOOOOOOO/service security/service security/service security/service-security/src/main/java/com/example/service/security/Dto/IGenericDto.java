package com.example.service.security.Dto;

public interface IGenericDto {
	Long getId();

	Boolean getState();
}

package com.example.service.security.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.ICountryDto;
import com.example.service.security.Dto.IRoleDto;
import com.example.service.security.Entity.Role;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.IRoleRepository;
import com.example.service.security.IService.IRoleService;

@Service
public class RoleService extends ABaseService<Role> implements IRoleService{

	@Override
	public IBaseRepositoy<Role, Long> getRepository() {
		return repository;
	}
	
	@Override
    public void delete(Long id) {
        repository.deleteById(id);
    }
	
	@Autowired
	public IRoleRepository repository;

	@Override
	public List<IRoleDto> getList() {
		return repository.getList();
	}

		
}

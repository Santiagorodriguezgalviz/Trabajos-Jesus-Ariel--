package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.IModuleDto;
import com.example.service.security.Entity.Module;

public interface IModuleService extends IBaseService<Module> {

	List<IModuleDto> getList();

}

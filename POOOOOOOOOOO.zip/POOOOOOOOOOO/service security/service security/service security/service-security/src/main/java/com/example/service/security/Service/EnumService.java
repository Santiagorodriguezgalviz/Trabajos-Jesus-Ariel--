package com.example.service.security.Service;

import org.springframework.stereotype.Service;


import com.example.service.security.Utils.weekdays;
import com.example.service.security.Utils.Adrees;
import com.example.service.security.Utils.Gender;
import com.example.service.security.Utils.Type_Document;
import com.example.service.security.IService.IEnumService;

@Service
public class EnumService implements IEnumService{


	@Override
	public Type_Document[] getDocument_Type() {
		// TODO Auto-generated method stub
		return Type_Document.values();
	}
	
@Override

public Gender[] getgender() {
	return Gender.values();
}
	@Override
	public weekdays[] getWeekdays() {
		// TODO Auto-generated method stub
		return weekdays.values();
	}
	
	
@Override
public Adrees[] getAdrees() {
	
	return Adrees.values();   
}
	
}

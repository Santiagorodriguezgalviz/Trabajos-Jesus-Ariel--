package com.example.service.security.Dto;

import com.example.service.security.Entity.InsumoProducto;
import com.example.service.security.Entity.Inventario;

public interface InventarioDetalle extends IGenericDto {

	InsumoProducto getInsumoproducto();

	String getCantidad();

	String getPrecioUnitario();

	String getInsumoProducto();

	Inventario getInventario();

}

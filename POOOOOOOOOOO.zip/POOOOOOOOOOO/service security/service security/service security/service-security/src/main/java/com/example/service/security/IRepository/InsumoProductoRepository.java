package com.example.service.security.IRepository;
import com.example.service.security.Entity.InsumoProducto;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.InsumoProductoDto;
@Repository
public interface InsumoProductoRepository extends IBaseRepositoy<InsumoProducto, Long>{
	
	@Query(value = "SELECT ip.id AS id_insumo_producto, " +
            "ip.cantidad AS cantidad, " +
            "ip.adicional AS adicional, " +
            "ins.nombre AS nombre_insumo, " +
            "pro.nombre AS nombre_producto, " +
            "pro.codigo AS codigo_producto " +
            "FROM InsumoProducto ip " +
            "INNER JOIN Insumo ins ON ip.InsumoId = ins.Id " +
            "INNER JOIN Producto pro ON ip.ProductoId = pro.Id", nativeQuery = true)
	List<InsumoProductoDto> getInsumoProductoDto();
	
}

package com.example.service.security.Controller;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.InsumoProductoDto;
import com.example.service.security.Entity.InsumoProducto;
import com.example.service.security.IService.IInsumoProductoService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("v1/api/insumoproducto")
public class InsumoProductoController extends ABaseController<InsumoProducto, IInsumoProductoService> {

	public InsumoProductoController(IInsumoProductoService service) {
		super(service, "InsumoProductoController");
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<InsumoProductoDto>>> show(){
		
		try {
			List<InsumoProductoDto> entity =service.getInsumoProductoDto();
			return ResponseEntity.ok(new ApiResponseDto<List<InsumoProductoDto>>("Registro encontrado", entity,true));
		}catch(Exception e) {
			
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<InsumoProductoDto>>(e.getMessage(), null, false));
			
		}
	}

}

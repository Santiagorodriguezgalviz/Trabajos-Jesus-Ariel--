package com.example.service.security.IService;

import com.example.service.security.Entity.Historialinventario;

import java.util.List;

import com.example.service.security.Dto.Histrial_InventarioDto;

public interface IHistorialInventarioService extends IBaseService<Historialinventario> {
	
	
	List<Histrial_InventarioDto> getHistrial_InventarioDto();

}

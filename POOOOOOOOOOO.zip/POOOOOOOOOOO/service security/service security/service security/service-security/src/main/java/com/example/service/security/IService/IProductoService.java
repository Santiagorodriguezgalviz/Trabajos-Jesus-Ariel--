package com.example.service.security.IService;

import com.example.service.security.Entity.Producto;

import java.util.List;

import com.example.service.security.Dto.ProductoDto;

public interface IProductoService extends IBaseService<Producto> {

	 List<ProductoDto> getListProducto();
}

package com.example.service.security.Dto;

import com.example.service.security.Entity.Company;
import com.example.service.security.Entity.Person;
import com.example.service.security.Entity.Position;

public interface IEmployedDto extends IGenericDto {

	Person getPerson();

	String getSalary();

	Company getCompany();

	Position getPosition();
}

package com.example.service.security.IRepository;
import com.example.service.security.Entity.Inventario;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.InventarioDto;
@Repository
public interface InventarioRepository extends IBaseRepositoy<Inventario, Long>{
	
	 @Query(value = "SELECT i.id AS id_inventario, " +
	            "i.nombre AS nombre_inventario, " +
	            "i.codigo AS codigo_inventario, " +
	            "p.nombre AS nombre_producto, " +
	            "p.codigo AS codigo_producto " +
	            "FROM Inventario i " +
	            "INNER JOIN Producto p ON i.ProductoId = p.Id", nativeQuery = true)

	List<InventarioDto> getListInventarioDto();
}

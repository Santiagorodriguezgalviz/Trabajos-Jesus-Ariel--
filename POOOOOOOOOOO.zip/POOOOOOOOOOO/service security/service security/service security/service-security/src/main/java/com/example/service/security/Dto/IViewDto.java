package com.example.service.security.Dto;

public interface IViewDto extends IGenericDto {

	String getModule();

	String getDescription();

	String getName();

	String getRoute();

}

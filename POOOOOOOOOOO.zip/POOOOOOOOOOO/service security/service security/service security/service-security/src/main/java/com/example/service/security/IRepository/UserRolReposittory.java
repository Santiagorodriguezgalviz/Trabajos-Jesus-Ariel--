package com.example.service.security.IRepository;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.UserRoleDto;
import com.example.service.security.Dto.ViewRolDto;
import com.example.service.security.Entity.UserRole;
@Repository
public interface UserRolReposittory extends IBaseRepositoy<UserRole, Long>{

	
}

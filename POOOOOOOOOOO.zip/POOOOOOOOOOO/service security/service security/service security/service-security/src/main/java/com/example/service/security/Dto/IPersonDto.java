package com.example.service.security.Dto;

public interface IPersonDto extends IGenericDto {
	String getPerson();

	String getTypeDocument();

	String getCode();

	String getDocument();

	String getFirstName();

	String getLastName();

	Long getPerson_Id();
}

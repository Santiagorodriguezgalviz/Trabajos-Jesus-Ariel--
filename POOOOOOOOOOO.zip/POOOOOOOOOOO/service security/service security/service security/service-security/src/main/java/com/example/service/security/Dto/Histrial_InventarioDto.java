package com.example.service.security.Dto;

import com.example.service.security.Entity.inventarioDetalle;

public interface Histrial_InventarioDto extends IGenericDto {

	String getCode();

	inventarioDetalle getInventariodetalle();

}

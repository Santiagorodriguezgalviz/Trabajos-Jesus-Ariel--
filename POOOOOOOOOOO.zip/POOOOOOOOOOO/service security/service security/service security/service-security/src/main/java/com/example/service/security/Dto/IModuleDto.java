package com.example.service.security.Dto;

public interface IModuleDto extends IGenericDto {

	String getName();

	String getRoute();

	String getDescription();
}

package com.example.service.security.Dto;

public interface ProductoDto extends IGenericDto {

	String getNombre();

	String getPrecio();

	String getCodigo();

	String getCantidad();

	String getPrecioCosto();

}

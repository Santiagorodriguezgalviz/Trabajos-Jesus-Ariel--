package com.example.service.security.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.IPositionDto;
import com.example.service.security.Controller.ABaseController;
import com.example.service.security.Entity.Position;
import com.example.service.security.IService.IPositionService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/position")
public class PositionController extends ABaseController<Position, IPositionService> {

	public PositionController(IPositionService service) {
		super(service, "Position");
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<IPositionDto>>> show(){
		
		try {
			List<IPositionDto> entity =service.getListPositions();
			return ResponseEntity.ok(new ApiResponseDto<List<IPositionDto>>("Registro encontrado", entity,true));
		}catch(Exception e) {
			
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<IPositionDto>>(e.getMessage(), null, false));
			
		}
	}

}
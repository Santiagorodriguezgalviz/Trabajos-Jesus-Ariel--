package com.example.service.security.Dto;

import com.example.service.security.Entity.Role;
import com.example.service.security.Entity.View;

public interface ViewRolDto extends IGenericDto{
	View getView();
	Role getRole();
}

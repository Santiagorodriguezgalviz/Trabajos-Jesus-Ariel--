package com.example.service.security.Utils;

public enum weekdays {
	lunes,
	martes,
	miercoles,
	jueves,
	viernes,
	sabado,

}

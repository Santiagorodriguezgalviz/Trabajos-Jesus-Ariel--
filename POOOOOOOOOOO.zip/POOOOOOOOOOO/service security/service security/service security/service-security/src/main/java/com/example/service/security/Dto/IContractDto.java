package com.example.service.security.Dto;

public interface IContractDto extends IGenericDto {
	String getCode();

	String getStart_Date();

	String getEnd_Date();

	String getSalary();

	String getObject();

}

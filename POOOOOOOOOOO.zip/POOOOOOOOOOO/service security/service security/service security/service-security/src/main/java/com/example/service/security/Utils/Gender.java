package com.example.service.security.Utils;

public enum Gender {
Masculino,Femenino,Elicotero,CientoOnceTipos_de_gey
}

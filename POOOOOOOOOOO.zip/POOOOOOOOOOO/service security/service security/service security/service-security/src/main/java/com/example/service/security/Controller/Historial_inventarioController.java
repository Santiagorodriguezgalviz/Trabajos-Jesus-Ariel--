package com.example.service.security.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.Factura_Detalle;
import com.example.service.security.Dto.Histrial_InventarioDto;
import com.example.service.security.Entity.Historialinventario;
import com.example.service.security.IService.IHistorialInventarioService;


@CrossOrigin(origins="*")
@RestController
@RequestMapping("v1/api/historial_inventario")
public class Historial_inventarioController extends ABaseController<Historialinventario, IHistorialInventarioService>{
	public Historial_inventarioController(IHistorialInventarioService service) {
		super(service, "Historial_Inventario");
		// TODO Auto-generated constructor stub
	}
	//List<Histrial_InventarioDto> getHistrial_InventarioDto();
	
	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<Histrial_InventarioDto>>> show(){
		
		try {
			List<Histrial_InventarioDto> entity =service.getHistrial_InventarioDto();
			return ResponseEntity.ok(new ApiResponseDto<List<Histrial_InventarioDto>>("Registro encontrado", entity,true));
		}catch(Exception e) {
			
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<Histrial_InventarioDto>>(e.getMessage(), null, false));
			
		}
	}
	
	
	

}

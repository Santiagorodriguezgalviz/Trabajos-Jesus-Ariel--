package com.example.service.security.IService;

import com.example.service.security.Entity.Insumo;

import java.util.List;

import com.example.service.security.Dto.*;

public interface IInsumoService extends IBaseService<Insumo> {

	List<InsumoDto> getInsumoDto();

}

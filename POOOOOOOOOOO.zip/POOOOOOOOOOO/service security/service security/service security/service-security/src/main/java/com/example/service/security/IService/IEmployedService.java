package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.IEmployedDto;
import com.example.service.security.Entity.Employed;

public interface IEmployedService extends IBaseService<Employed> {
	List<IEmployedDto> getList();
}
package com.example.service.security.IService;

import java.util.Optional;

import com.example.service.security.Dto.IUserDto;
import com.example.service.security.Entity.User;

public interface IUserService extends IBaseService<User> {

	Optional<IUserDto> getUserWithViews(String username, String password);

}

package com.example.service.security.IService;

import java.util.List;
import java.util.Optional;

import com.example.service.security.Dto.ICityDto;
import com.example.service.security.Entity.City;

public interface ICityService extends IBaseService<City> {

	List<ICityDto> GetListCitys();

}

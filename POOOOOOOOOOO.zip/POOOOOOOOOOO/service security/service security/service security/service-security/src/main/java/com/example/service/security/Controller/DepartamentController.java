package com.example.service.security.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.IDepartamentDto;
import com.example.service.security.Entity.Departament;
import com.example.service.security.IService.IDepartamentService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/department")
public class DepartamentController extends ABaseController<Departament, IDepartamentService> {
	public DepartamentController(IDepartamentService service) {
		super(service, "Department");
	}

	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<IDepartamentDto>>> show() {
		try {
			List<IDepartamentDto> entity = service.getListDepartaments();
			return ResponseEntity.ok(new ApiResponseDto<List<IDepartamentDto>>("Registro encontrado", entity, true));
		} catch (Exception e) {
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<IDepartamentDto>>(e.getMessage(), null, false));
		}
	}
}
package com.example.service.security.IRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.service.security.Dto.ICityDto;
import com.example.service.security.Entity.City;

@Repository
public interface ICityRepository extends IBaseRepositoy<City, Long> {

    @Query(value = "SELECT `city`.`id`," +
            "            `city`.`created_at`," +
            "            `city`.`created_by`," +
            "            `city`.`deleted_at`," +
            "            `city`.`deleted_by`," +
            "            `city`.`state`," +
            "            `city`.`updated_at`," +
            "            `city`.`updated_by`," +
            "            `city`.`code` AS code_city," +
            "            `city`.`name` AS name_city," +
            "            `d`.`name` AS department" +
            "    FROM `service_security`.`city`" +
            "    INNER JOIN department AS d ON city.department_id = d.id", nativeQuery = true)
    List<ICityDto> GetListCitys();

    Optional<City> findById(Long id);
}
package com.example.service.security.Service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.ProductoDto;
import com.example.service.security.Entity.Producto;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.ProductoRepository;
import com.example.service.security.IService.IProductoService;
@Service
public class ProductoService extends ABaseService<Producto> implements IProductoService{

	@Override
	public IBaseRepositoy<Producto, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}
	@Autowired
	public ProductoRepository repository;
	
	@Override
	public List<ProductoDto> getListProducto(){
		return repository.getListProducto();
		
	}
	
	public void delete(Long id) {
		repository.deleteById(id);
	}

}

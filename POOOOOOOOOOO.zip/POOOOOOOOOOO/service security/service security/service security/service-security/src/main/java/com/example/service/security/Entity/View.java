package com.example.service.security.Entity;

import java.util.HashSet;
import java.util.Set;

import org.antlr.v4.runtime.misc.NotNull;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "view")
public class View extends ABaseEntity {

	@Column(name = "name", length = 50, nullable = false)
	private String name;

	@Column(name = "route", length = 50, nullable = false)
	private String route;

	@Column(name = "description", length = 50, nullable = false, unique = true)
	private String description;
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "module_id", nullable = false)
	private Module module;
	@NotNull
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "view_role", schema = "security", joinColumns = @JoinColumn(name = "view_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> role = new HashSet<>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		this.route = route;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<Role> getRole() {
		return role;
	}

	public void setRole(Set<Role> role) {
		this.role = role;
	}

///-------------////
	public Module getModule() {
		return module;
	}

	public void setModule(Module module) {
		this.module = module;
	}

}
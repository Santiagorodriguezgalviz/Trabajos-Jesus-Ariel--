package com.example.service.security.Dto;

public interface IRoleDto extends IGenericDto {
	String getRole();

	String getDescription();

}

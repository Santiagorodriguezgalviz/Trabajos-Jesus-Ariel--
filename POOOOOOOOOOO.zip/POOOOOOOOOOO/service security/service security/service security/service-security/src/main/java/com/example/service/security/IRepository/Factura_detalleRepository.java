package com.example.service.security.IRepository;
import java.util.List;


import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.Factura_Detalle;
import com.example.service.security.Entity.detalle_factura;
@Repository
public interface Factura_detalleRepository extends IBaseRepositoy<detalle_factura, Long> {
	@Query(value = "SELECT fd.id AS id_factura_detalle, " +
            "fd.subtotal AS subtotal, " +
            "f.id AS id_factura, " +
            "f.total AS total_factura, " +
            "f.fecha AS fecha_factura " +
            "FROM FacturaDetalle fd " +
            "INNER JOIN Factura f ON fd.FacturaId = f.Id", nativeQuery = true)
	List<Factura_Detalle> getFactura_Detalle();
}

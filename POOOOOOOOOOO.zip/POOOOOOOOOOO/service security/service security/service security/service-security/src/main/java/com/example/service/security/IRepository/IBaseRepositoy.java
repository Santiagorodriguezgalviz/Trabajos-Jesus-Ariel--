package com.example.service.security.IRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.service.security.Entity.ABaseEntity;

@Repository
public interface IBaseRepositoy<T extends ABaseEntity, ID> extends JpaRepository<T, Long> {

}

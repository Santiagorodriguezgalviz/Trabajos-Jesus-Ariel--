package com.example.service.security.Dto;

import com.example.service.security.Entity.Insumo;
import com.example.service.security.Entity.Producto;

public interface InsumoProductoDto extends IGenericDto {

	String getCantidad();

	String getAdicional();

	Producto getProducto();

	Insumo getInsumo();

}

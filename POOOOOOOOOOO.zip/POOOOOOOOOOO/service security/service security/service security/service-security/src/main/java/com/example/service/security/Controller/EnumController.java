package com.example.service.security.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.ICityDto;
import com.example.service.security.Dto.IPersonDto;
import com.example.service.security.Utils.Adrees;
import com.example.service.security.Utils.Gender;
import com.example.service.security.Utils.Type_Document;
import com.example.service.security.Utils.weekdays;

import com.example.service.security.IService.IEnumService;

import org.springframework.web.bind.annotation.RequestParam;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/enum")
public class EnumController {
	@Autowired
	public IEnumService service;

	@GetMapping("/tipo_documento")
	public Type_Document[] TipoDocumento() {
		return service.getDocument_Type();
	}

	@GetMapping("/weekdays")
	public weekdays[] weekdays() {
		return service.getWeekdays();
	}
	
	
	@GetMapping("/gender")
	public Gender[] getgender() {
		return service.getgender();
	}
	
	@GetMapping("/address")
	public Adrees[] getAdrees() {
		
		return service.getAdrees();
	}
	
	
	
	/*
	 * @GetMapping("/meses") public MesesEnum[] meses() { return service.getMeses();
	 * }
	 */

}

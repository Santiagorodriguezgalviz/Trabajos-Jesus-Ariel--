package com.example.service.security.IRepository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.FacturaDto;
import com.example.service.security.Entity.Factura;
@Repository
public interface FacturaRepository extends IBaseRepositoy<Factura, Long>{

	@Query(value = "SELECT f.id AS id_factura, " +
            "f.total AS total_factura, " +
            "c.id AS id_cliente, " +
            "c.codigo AS codigo_cliente, " +
            "p.nombre AS nombre_producto, " +
            "p.codigo AS codigo_producto, " +
            "p.precio AS precio_producto " +
            "FROM Factura f " +
            "INNER JOIN Customer c ON f.CustomerId = c.id " +
            "INNER JOIN Producto p ON f.ProductoId = p.id", nativeQuery = true)
	
	List<FacturaDto> getFacturaDto();

	
}

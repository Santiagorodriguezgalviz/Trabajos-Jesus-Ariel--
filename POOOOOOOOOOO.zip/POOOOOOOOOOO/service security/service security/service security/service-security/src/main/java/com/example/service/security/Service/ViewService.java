package com.example.service.security.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.ICountryDto;
import com.example.service.security.Dto.IViewDto;
import com.example.service.security.Entity.View;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.IViewRepository;
import com.example.service.security.IService.IViewService;

@Service
public class ViewService extends ABaseService<View> implements IViewService{

	@Override
	public IBaseRepositoy<View, Long> getRepository() {
		return repository;
	}
	
	@Override
    public void delete(Long id) {
        repository.deleteById(id);
    }
	
	
	@Autowired
	public IViewRepository repository;

	@Override
	public List<IViewDto> getList() {
		return repository.getList();
	}

	
	
	
}
package com.example.service.security.IRepository;
import com.example.service.security.Entity.UnidadesDeMedida;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.UnidadesDeMedidaDto;
@Repository
public interface UnidadesDeMedidaRepository extends IBaseRepositoy<UnidadesDeMedida, Long> {
	@Query(value = "SELECT nombre AS nombre_unidad, "
			+ "codigo AS codigo_unidad FROM UnidadesDeMedida"
			, nativeQuery = true)
	
	List <UnidadesDeMedidaDto> getUnidadesDeMedidaDto();
}

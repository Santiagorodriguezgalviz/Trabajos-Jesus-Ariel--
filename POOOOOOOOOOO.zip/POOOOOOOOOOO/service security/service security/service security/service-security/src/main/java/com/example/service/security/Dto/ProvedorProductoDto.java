package com.example.service.security.Dto;

import com.example.service.security.Entity.Person;
import com.example.service.security.Entity.Producto;

public interface ProvedorProductoDto extends IGenericDto {

	Producto getProducto();

	Person getPerson();

}

package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.ICompanyDto;
import com.example.service.security.Entity.Company;

public interface ICompanyService extends IBaseService<Company> {
	List<ICompanyDto> getList();

}

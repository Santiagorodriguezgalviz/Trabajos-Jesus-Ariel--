package com.example.service.security.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.IEmployedDto;
import com.example.service.security.Entity.Employed;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.IEmployedRepository;
import com.example.service.security.IService.IEmployedService;

@Service
public class EmployedService extends ABaseService<Employed> implements IEmployedService{

	@Override
	public IBaseRepositoy<Employed, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}
	
	@Override
	public void delete(Long id) {
	    repository.deleteById(id);
	}
	
	@Autowired
	public IEmployedRepository repository;

	
	@Override
	public List<IEmployedDto> getList() {
		// TODO Auto-generated method stub
		return repository.getList();
	}

	
	
}

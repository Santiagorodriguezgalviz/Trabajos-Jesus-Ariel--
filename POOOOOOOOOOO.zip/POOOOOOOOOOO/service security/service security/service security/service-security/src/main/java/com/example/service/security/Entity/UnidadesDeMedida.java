package com.example.service.security.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
@Entity
@Table(name="UnidadesDeMedida ")
public class UnidadesDeMedida extends ABaseEntity {

	@Column(name = "Nombre", nullable = false, unique = false)
	private String Nombre;

	@Column(name = "Codigo", nullable = false, unique = false)
	private String Codigo;

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getCodigo() {
		return Codigo;
	}

	public void setCodigo(String codigo) {
		Codigo = codigo;
	}

}

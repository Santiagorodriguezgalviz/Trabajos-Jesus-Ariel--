package com.example.service.security.Service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.ProvedorProductoDto;
import com.example.service.security.Entity.ProvedorProducto;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IRepository.ProvedorProductoRepository;
import com.example.service.security.IService.IProvedorProductoService;
@Service
public class ProvedorProductoService extends ABaseService<ProvedorProducto> implements IProvedorProductoService {

	@Override
	public List<ProvedorProductoDto> getListProvedorProducto() {
		// TODO Auto-generated method stub
		return repository.getListProvedorProducto();
	}

	@Autowired
	public ProvedorProductoRepository repository;
	
	@Override
	public IBaseRepositoy<ProvedorProducto, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	
}

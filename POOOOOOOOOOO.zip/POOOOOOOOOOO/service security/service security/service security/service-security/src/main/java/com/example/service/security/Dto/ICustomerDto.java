package com.example.service.security.Dto;

import com.example.service.security.Entity.Person;

public interface ICustomerDto extends IGenericDto {
	String getCode();
	String getType_document();
	String getName();
	String getDocument();
	Person getPerson();

}

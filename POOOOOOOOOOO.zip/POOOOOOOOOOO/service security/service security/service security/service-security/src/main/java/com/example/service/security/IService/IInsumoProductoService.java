package com.example.service.security.IService;

import java.util.List;

import com.example.service.security.Dto.InsumoProductoDto;
import com.example.service.security.Entity.InsumoProducto;

public interface IInsumoProductoService extends IBaseService<InsumoProducto> {
	List<InsumoProductoDto> getInsumoProductoDto();
}

package com.example.service.security.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "insumo")
public class Insumo extends ABaseEntity {

	@Column(name = "Nombre", nullable = false, unique = false)
	private String Nombre;

	@Column(name = "Descripcion", nullable = false, unique = false)
	private String Descripcion;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "UnidadesDeMedida_id", nullable = false)
	private UnidadesDeMedida UnidadesDeMedida;

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getDescripcion() {
		return Descripcion;
	}

	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

	public UnidadesDeMedida getUnidadesDeMedida() {
		return UnidadesDeMedida;
	}

	public void setUnidadesDeMedida(UnidadesDeMedida unidadesDeMedida) {
		UnidadesDeMedida = unidadesDeMedida;
	}

}

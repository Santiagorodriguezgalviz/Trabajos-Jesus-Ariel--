package com.example.service.security.IRepository;
import com.example.service.security.Entity.ProvedorProducto;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.service.security.Dto.*;
@Repository
public interface ProvedorProductoRepository extends IBaseRepositoy<ProvedorProducto, Long>{
	
	@Query(value = "SELECT pp.id AS id_provedor_producto, " +
			"pp.producto_id AS producto_id, " +
			"p.id AS id_producto, " +
			"pp.person_id AS person_id, " +
			"per.id AS id_person " +
			"FROM provedor_producto pp " +
			"INNER JOIN producto p ON pp.producto_id = p.id " +
			"INNER JOIN person per ON pp.person_id = per.id", nativeQuery = true)
	List<ProvedorProductoDto> getListProvedorProducto();

	
}

package com.example.service.security.IService;

import com.example.service.security.Entity.Inventario;

import java.util.List;

import com.example.service.security.Dto.InventarioDto;

public interface IInventarioService extends IBaseService<Inventario> {

	List<InventarioDto> getListInventarioDto();

}

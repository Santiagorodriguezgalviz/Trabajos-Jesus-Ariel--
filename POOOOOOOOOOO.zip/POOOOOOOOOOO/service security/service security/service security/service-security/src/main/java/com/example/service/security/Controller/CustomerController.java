package com.example.service.security.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.security.Dto.ApiResponseDto;
import com.example.service.security.Dto.ICustomerDto;
import com.example.service.security.Entity.Customer;
import com.example.service.security.Entity.Person;
import com.example.service.security.IService.ICustomerService;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/customer")
public class CustomerController extends ABaseController<Customer, ICustomerService> {

	public CustomerController(ICustomerService service) {
		super(service, "Client");
		// TODO Auto-generated constructor stub
	}

	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<ICustomerDto>>> show() {
		try {
			List<ICustomerDto> entity = service.getListICustomerDto();
			return ResponseEntity.ok(new ApiResponseDto<List<ICustomerDto>>("Registro encontrado", entity, true));
		} catch (Exception e) {
			return ResponseEntity.internalServerError()
					.body(new ApiResponseDto<List<ICustomerDto>>(e.getMessage(), null, false));
		}
	}

	@PostMapping("/personCliente")
	public ResponseEntity<ApiResponseDto<Customer>> save(@RequestBody Person entity) {
		try {
			return ResponseEntity
					.ok(new ApiResponseDto<Customer>("Datos guardados", service.savePersonCustomer(entity), true));
		} catch (Exception e) {
			return ResponseEntity.internalServerError().body(new ApiResponseDto<Customer>(e.getMessage(), null, false));
		}
	}

}

package com.example.service.security.Service;
import com.example.service.security.Entity.detalle_factura;

import com.example.service.security.IRepository.Factura_detalleRepository;
import com.example.service.security.IRepository.IBaseRepositoy;
import com.example.service.security.IService.IFactura_DetalleService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.service.security.Dto.Factura_Detalle;
@Service
public class Factura_DetalleService extends ABaseService<detalle_factura> implements IFactura_DetalleService {

	@Override
	public List<Factura_Detalle> getFactura_Detalle() {
		// TODO Auto-generated method stub
		return repository.getFactura_Detalle();
	}
	
@Autowired
public Factura_detalleRepository repository;

	@Override
	public IBaseRepositoy<detalle_factura, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	
}
